import pandas as pd
import apiHandler as ah
import trainerEngine as te
import pandas as pd



class BackEndEngine:
    
    def __init__(self, token):
        self.__token = token
        self.__posts = ah.PostsGrabber(self.__token)
        self.__trainer = te.TrainerEngine()

    def displayTrainData(self, postIter = 3):
        """1 postIter = 25posts. Ex: If postIter = 3, it will try to get at most 75 posts if available"""
        self.__posts.execute(counts= postIter)
        self.__trainer.trainData(dataFrame= self.__posts.getDF())
        self.__trainer.displayDF()
        self.__trainer.exportCSV()
    def getPageDemographicsData(self):
        return self.__demographics.getDemographics()
    def getTrainedDF(self):
        self.__posts.execute(counts= 5)
        df = self.__posts.getDF()
        if(type(df) is list):
            print("Wrong Token!")
            return df
        self.__trainer.trainData(dataFrame= df )
        return self.__trainer.getDF()
    def getTestTrainedDF(self):
        self.__trainer.trainData()
        return self.__trainer.getDF()



# token = "EAAZA9cOuu2jsBAI3foPZCigPiYaZAJWvWEV8ZB7JhBeHBb7TRNNiO8iPM9DrC2PIzd2NgNUiY9d57IthXYHUNCK1lPowAkqZBYCLqSJbdQJ1plmxcnfu9OM3HLmTUAwJacigQvqZCZCA7M4CDmQHlIZClBPXXwUvuM2VZA8s8FveNqkq12ecTLf3IZA9JH1sDOgo233GgCZCKUcD6Wwae8MD8hR"


# eng = BackEndEngine(token= token)


# eng.getTestTrainedData()


3#fb.ap(page_fans_city) 
# page_fans_gender_age  
# page_fan_adds/days (loop)
# page_fan_removes (loop)

1 # # PageLikes/Dislikes:  (page_fan_adds/page_fan_removes)
# manitouClass.getPage()
# [
#     ["day","months","likes"],[],[]
# ]
# item[1][2]

2# Gender: 
# page_fans_gender_age
# class.getFanGenderAge()
# [
#     ["Gender","14-16","TotalNumbers" ],[],[]
# ]

#page_impressions




